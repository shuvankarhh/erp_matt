import tippy from "tippy.js";

if (document.querySelectorAll('[data-plugin="tippy"]').length > 0) {
    tippy('[data-plugin="tippy"]');
}
