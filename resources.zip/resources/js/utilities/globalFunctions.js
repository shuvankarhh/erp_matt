// resources/js/utilities/globalFunctions.js

export function greet(name) {
    return `Hello, ${name}!`;
}

export function add(a, b) {
    return a + b;
}
