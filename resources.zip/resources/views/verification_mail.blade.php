Dear {{ $user_name }},

Your verification code is

{{ $verification_code }}

Please enter this code when prompted by the Forgot Password process at {{ config('app.url') }}

You are receiving this email because the email address was used during the Forgot Password process at {{ config('app.url') }}.  If you are not the intended recipient, then you can disregard this email.

Support Team,
{{ $website_setting->company_name }}