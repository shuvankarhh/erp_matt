<x-modal-layout layout="{{ isset($layout) ? $layout : null }}">
    {{-- Blank --}}
</x-modal-layout>

{{-- <x-large-modal-layout layout="{{ isset($layout) ? $layout : null }}">
    Blank
</x-large-modal-layout> --}}
