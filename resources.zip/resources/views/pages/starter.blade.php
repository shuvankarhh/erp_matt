@extends('layouts.vertical', ['title' => 'Starter', 'sub_title' => 'Pages', 'mode' => $mode ?? '', 'demo' => $demo ?? ''])

@section('content')
    <div class="grid grid-cols-12">
        <div class="col-span-12">

        </div>
    </div>
@endsection
