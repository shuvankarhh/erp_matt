<td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800 dark:text-gray-200 {{ $class }}">
    {{ $slot }}
</td>
