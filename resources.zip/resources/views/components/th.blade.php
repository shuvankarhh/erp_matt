<th scope="col"
    {{ $attributes->merge(['class' => "px-6 py-3 text-xs font-medium text-gray-500 uppercase $align"]) }}>
    {{ $slot }}

    {{-- <th class="px-6 py-3 text-left text-sm font-semibold text-gray-700">ID</th> --}}

</th>
