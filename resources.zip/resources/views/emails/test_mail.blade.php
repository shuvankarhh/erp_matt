<!DOCTYPE html>
<html>

<head>
    <title>Test Email</title>
</head>

<body>
    <h1>Test Email</h1>
    <p>If you see this message, the email functionality is working!</p>
</body>

</html>
