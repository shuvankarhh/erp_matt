<?php

namespace App\Services;

class BuiltInWebsiteSettings
{
    public static $email_per_hour = 50; // for sending email
}
